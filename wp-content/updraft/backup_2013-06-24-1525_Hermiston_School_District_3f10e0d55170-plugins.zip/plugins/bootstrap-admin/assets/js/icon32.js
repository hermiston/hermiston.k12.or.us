jQuery(document).ready( function() {
  jQuery('#icon-index.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-dashboard icon-large"></i></div> ');
  jQuery('#icon-edit.icon32-posts-post').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-pencil icon-large"></i></div> ');
  jQuery('#icon-upload.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-picture icon-large"></i></div> ');
  jQuery('#icon-link-manager.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-link icon-large"></i></div> ');
  jQuery('#icon-edit-pages.icon32-posts-page').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-file icon-large"></i></div> ');
  jQuery('#icon-edit-comments.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-comment icon-large"></i></div> ');
  jQuery('#icon-edit.icon32-posts-portfolio').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-th-large icon-large"></i></div> ');
  jQuery('#icon-wpcf7.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-edit icon-large"></i></div> ');
  jQuery('#icon-edit-news.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-envelope-alt icon-large"></i></div> ');
  jQuery('#icon-edit.icon32.icon32-posts-forum').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-group icon-large"></i></div> ');
  jQuery('#icon-edit.icon32.icon32-posts-topic').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-comments icon-large"></i></div> ');
  jQuery('#icon-edit.icon32.icon32-posts-reply').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-comments-alt icon-large"></i></div> ');
  jQuery('#icon-themes.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-eye-open icon-large"></i></div> ');
  jQuery('#icon-plugins.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-magnet icon-large"></i></div> ');
  jQuery('#icon-users.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-user icon-large"></i></div> ');
  jQuery('#icon-tools.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-wrench icon-large"></i></div> ');
  jQuery('#icon-options-general.icon32').replaceWith('<div style="font-size:22px;" class="icon32 fonticon"><i class="icon-cogs icon-large"></i></div> ');
});
