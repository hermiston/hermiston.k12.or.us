<div class="rhc-organizer">
	<div class="rhc-organizer-name">
		<a href="{website}">{name}</a>
	</div>
	<div class="rhc-organizer-phone">{phone}</div>
	<div class="rhc-organizer-email">{email}</div>
	<div class="rhc-organizer-description">{description}</div>
</div>