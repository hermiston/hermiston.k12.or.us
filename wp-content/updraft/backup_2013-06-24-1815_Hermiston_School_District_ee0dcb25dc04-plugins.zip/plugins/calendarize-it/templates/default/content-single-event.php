[featuredimage meta_key='enable_featuredimage' meta_value='1' default='1' custom='rhc_top_image']<?php echo $content ?>
[postinfo meta_key='enable_postinfo' meta_value='1' default='1' class="se-dbox"]
[postinfo meta_key='enable_venuebox' meta_value='1' default='1' id="venuebox" class="se-vbox"]
