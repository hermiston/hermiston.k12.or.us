<?php

// Set to 1 to use php-less compiling. Useful while theming using less
define('BOOTSTRAP_ADMIN_LESS_MODE', '0');

// Set to 1 to use chosen js for select elements
define('BOOTSTRAP_ADMIN_CHOSEN_JS', '0');
